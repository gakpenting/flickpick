live https://flickpicktest.herokuapp.com/

- install python 3
- run command
```
pip3 install -r requirements.txt
```

- run command

```
python3 myproject.py
```

-open browser open localhost:5000